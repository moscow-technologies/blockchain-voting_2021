<?php

namespace App\Component\Validation\Exception;

class TelephoneOrEmailNotConfirmed extends ValidationException {

}