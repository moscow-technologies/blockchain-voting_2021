<?php

namespace App\Component\Validation\Exception;

class AgreementRequired extends ValidationException {}