<?php

namespace App\Component\Amqp;

class Consumer extends Connection {

}