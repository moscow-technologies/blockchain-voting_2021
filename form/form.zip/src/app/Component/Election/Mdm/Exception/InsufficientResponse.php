<?php


namespace App\Component\Election\Mdm\Exception;


class InsufficientResponse extends Base {

}