<?php

namespace App\Component\Election\Mdm\Exception;

class RevotingLimitExceeded extends Base {
    
}