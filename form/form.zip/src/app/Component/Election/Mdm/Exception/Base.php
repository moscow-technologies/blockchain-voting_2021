<?php


namespace App\Component\Election\Mdm\Exception;

use App\Exceptions;

class Base extends Exceptions\Base {

}