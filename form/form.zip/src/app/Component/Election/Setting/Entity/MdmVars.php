<?php

namespace App\Component\Election\Setting\Entity;

class MdmVars {

    public $url;
    public $token;
    public $hmacSalt;
}