<?php

namespace App\Component\Election\Exception;

use App\Exceptions;

class Base extends Exceptions\Base {
    
}