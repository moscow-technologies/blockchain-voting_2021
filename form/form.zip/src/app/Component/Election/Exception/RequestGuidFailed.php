<?php

namespace App\Component\Election\Exception;

class RequestGuidFailed extends Base {
    
}