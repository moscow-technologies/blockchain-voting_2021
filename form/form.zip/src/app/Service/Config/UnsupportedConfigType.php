<?php
/**
 * Created by PhpStorm.
 * User: artiom
 * Date: 06.06.17
 * Time: 15:09
 */

namespace App\Service\Config;

use Exception;

class UnsupportedConfigType extends Exception
{

}