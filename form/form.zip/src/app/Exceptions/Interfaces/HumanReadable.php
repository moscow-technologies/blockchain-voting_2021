<?php

namespace App\Exceptions\Interfaces;

interface HumanReadable {

}