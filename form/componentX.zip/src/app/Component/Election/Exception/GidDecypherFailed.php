<?php

namespace App\Component\Election\Exception;

class GidDecypherFailed extends Base {
    
}