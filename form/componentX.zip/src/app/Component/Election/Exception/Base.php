<?php

namespace App\Component\Election\Exception;

class Base extends \Exception {
    
}