<?php


namespace App\Component\Election\Mdm\Exception;


class InvalidResponse extends Base {

}