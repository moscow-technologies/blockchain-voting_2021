<?php


namespace App\Component\Election\Mdm\Exception;


class NetworkError extends Base {

}