<?php


namespace App\Component\Election\Mdm\Exception;


class Base extends \Exception {

}