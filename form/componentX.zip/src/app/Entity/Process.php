<?php


namespace App\Entity;


class Process {
    public $startTime;
    public $tag;
    public $url;
}