<?php
if (cfg('services/mos_ru/widgetLive',true)) {
?>
   <script type="text/javascript" src="<?php print params::$mosHost;?>/widget-collection/main.js" ></script>
<?php
}