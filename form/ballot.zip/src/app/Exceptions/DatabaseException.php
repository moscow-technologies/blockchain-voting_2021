<?php

namespace App\Exceptions;

/**
 * Class DatabaseException
 * @package Itb\Mpgu\Core\Exceptions
 */
class DatabaseException extends BaseException {/*_*/}
