<?php
/**
 * Created by PhpStorm.
 * User: serqol
 * Date: 25.05.20
 * Time: 6:14
 */

namespace App\Exceptions;


class BallotException extends \Exception {

}