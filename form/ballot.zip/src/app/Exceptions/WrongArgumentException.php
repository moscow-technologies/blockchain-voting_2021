<?php

namespace App\Exceptions;

/**
 * Class WrongArgumentException
 * @package Itb\Mpgu\Core\Exceptions
 */
class WrongArgumentException extends BaseException {/*_*/}
