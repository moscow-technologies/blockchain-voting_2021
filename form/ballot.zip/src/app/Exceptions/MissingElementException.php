<?php

namespace App\Exceptions;

/**
 * Class MissingElementException
 * @package Itb\Mpgu\Core\Exceptions
 */
class MissingElementException extends BaseException {/*_*/}
