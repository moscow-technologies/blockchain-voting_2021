<?php

namespace App\Exceptions;

/**
 * Class ObjectNotFoundException
 * @package exceptions
 */
class ObjectNotFoundException extends DatabaseException {/*_*/}
