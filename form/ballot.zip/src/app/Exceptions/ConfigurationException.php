<?php

namespace App\Exceptions;

/**
 * Class ConfigurationException
 * @package Itb\Mpgu\Core\Exceptions
 */
class ConfigurationException extends BaseException {/*_*/}
