<?php

namespace App\Exceptions;

/**
 * Class UnsupportedMethodException
 * @package Itb\Mpgu\Core\Exceptions
 */
class UnsupportedMethodException extends BaseException {/*_*/}
