<?php

namespace App\Exceptions;

/**
 * Class SecurityException
 * @package exceptions
 */
class SecurityException extends \Exception {/*_*/}
