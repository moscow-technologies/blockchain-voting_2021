<?php

namespace App\Exceptions;

/**
 * Class WrongStateException
 * @package Itb\Mpgu\Core\Exceptions
 */
class WrongStateException extends BaseException {/*_*/}
