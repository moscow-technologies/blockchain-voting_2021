<?php

namespace App\Component\Election\Exception;

class HashGroupsInvalid extends Base {
    
}