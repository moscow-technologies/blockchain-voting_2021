<?php

namespace App\Component\Election\Exception;

class BallotDoesNotExist extends Base {

}