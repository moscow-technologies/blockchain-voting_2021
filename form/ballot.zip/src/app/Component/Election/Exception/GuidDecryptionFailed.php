<?php

namespace App\Component\Election\Exception;

class GuidDecryptionFailed extends Base {

}