<?php

namespace App\Component\Election\Exception;

class GuidDoesNotExist extends Base {

}
