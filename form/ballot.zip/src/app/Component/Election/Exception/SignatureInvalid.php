<?php

namespace App\Component\Election\Exception;

class SignatureInvalid extends Base {
    
}