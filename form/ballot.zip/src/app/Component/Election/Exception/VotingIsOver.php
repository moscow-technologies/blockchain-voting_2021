<?php

namespace App\Component\Election\Exception;

class VotingIsOver extends Base {

}
