<?php

namespace App\Component\Election\Exception;

class VotingHasNotStarted extends Base {

}
