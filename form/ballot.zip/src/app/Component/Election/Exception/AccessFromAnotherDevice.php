<?php

namespace App\Component\Election\Exception;

class AccessFromAnotherDevice extends Base {
    
}