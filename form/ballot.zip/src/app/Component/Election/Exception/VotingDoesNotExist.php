<?php

namespace App\Component\Election\Exception;

class VotingDoesNotExist extends Base {
}
