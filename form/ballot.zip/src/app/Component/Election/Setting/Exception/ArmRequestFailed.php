<?php

namespace App\Component\Election\Setting\Exception;

use App\Exceptions;

class ArmRequestFailed extends Exceptions\Base {
}