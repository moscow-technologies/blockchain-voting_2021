<?php

namespace App\Component\ConnectionPool;

use Smf\ConnectionPool\ConnectionPoolTrait;

class Keeper {

    use ConnectionPoolTrait;
}
