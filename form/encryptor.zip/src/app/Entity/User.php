<?php

namespace App\Entity;

class User {

    public $id;
    public $phone;

}