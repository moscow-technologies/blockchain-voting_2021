<?php


namespace App\Http\Middleware;


class ValidateAccess {

    public function handle() {

    }
}